clear all;
close all;
addpath helpfunction;

load('YaleBCrop025.mat');

nSet = [2 3 5 8 10];

%ADMM parameters
param.rho=1.5; param.mu=1e-6;    param.tol=1e-6; param.maxIter=500;

type = 3;   %different modeling of E.

for lambda = 0.01
    for a = 150
        for psd = 0
            for alpha = 3
                for i = 1%1 : length(nSet)
                    n = nSet(i);
                    missrateTot{n} = [];
                    idx = Ind{n};
                    for j = 1 : size(idx,1)
                        X = [];
                        for p = 1 : n
                            X = [X Y(:,:,idx(j,p))];
                        end
                        X = mat2gray(X);
                        K = n;

                        Z = solve_TS1(X, lambda, 1, a, param, type);         %%F����
                        
%                         name = sprintf(['./results/ExtendYaleB/ExtendYaleB_n_' num2str(n) '_j_' num2str(j) '_lambda_' num2str(lambda) '_a_' num2str(a) '.mat']);
%                         save(name,'Z');
%                         load(name);
                        if psd > 0
                            Z = rpcapsd(Z,psd);
                        end
                        %post processing
                        [U ss V] = svd(Z);
                        ss = diag(ss);
                        r = sum(ss>1e-6);
                        
                        U = U(:, 1 : r);
                        ss = diag(ss(1 : r));
                        V = V(:, 1 : r);
                        
                        M = U * ss.^(1/2);
                        mm = normr(M);
                        rs = mm * mm';
                        L = rs.^(2 * alpha);

                        % spectral clustering
                        W = L;
                        W = (W+W')/2;
                        D = diag(1./sqrt(sum(W, 2)));
                        W = D * W * D;
                        [U, SS, V] = svd(W);
                        V = U(:, 1 : K);
                        V = normr(V);
                        actual_ids = kmeans(V, K, 'emptyaction', 'singleton', 'replicates', 20, 'display', 'off');
                        
                        grps = bestMap(s{n},actual_ids);
                        missrate = sum(s{n}(:) ~= grps(:)) / length(s{n});
                        disp(missrate);

                        missrateTot{n}(j) = missrate;
                        avgmissrate(n) = mean(missrateTot{n});
                        medmissrate(n) = median(missrateTot{n});
                        
                        disp(['subjects=' num2str(n) ',sequence=' num2str(j) ',lambda=' num2str(lambda) ', a=' num2str(a) ', rho=' num2str(param.rho) ', mu=' num2str(param.mu) ', tol=' num2str(param.tol) ', maxIter=' num2str(param.maxIter) ',psd=' num2str(psd) ',alpha=' num2str(alpha) ', seg missrate=' num2str(missrate) ', seg avgmissrate=' num2str(avgmissrate(n))]);
                        
                        filename = (['.\results\ExtendYaleB\TS1LLRR_face_YaleB_' num2str(n) '_detail.txt']);
%                         dlmwrite(filename, [n j lambda a param.rho param.mu param.tol param.maxIter psd alpha missrate avgmissrate(n) medmissrate(n)] , '-append', 'delimiter', '\t', 'newline', 'pc');%����
                    end
                    filename = (['.\results\ExtendYaleB\TS1LLRR_face_YaleB_' num2str(n) '.txt']);
%                     dlmwrite(filename, [n lambda a param.rho param.mu param.tol param.maxIter psd alpha avgmissrate(n) medmissrate(n)] , '-append', 'delimiter', '\t', 'newline', 'pc');%����
                end
            end
        end
    end
end




