function [Z,L,E] = solve_TS1a(X,A,B,beta,alpha,a,param, type)
% This routine solves the optmization problem of TS1-LLRR (noisy model)
% min T(Z) + alpha*T(L) + beta*|E|_1
% s.t., X = AZ + LB + E  
%where T(.) is the transformed Schatten-1 (TS1) penalty function.
% inputs:
%        X -- D*N data matrix, D is the data dimension, and N is the number
%             of data vectors.
%        alpha -- usually alpha = 1
%        beta  -- this parameter depends on the noise level of data
%%

rho = param.rho; mu = param.mu; tol = param.tol; maxIter = param.maxIter;
max_mu = 1e10; 


[d n] = size(X);
nA = size(A,2);
dB = size(B,1);

ata = A'*A;
bbt = B*B';
inv_ata = inv(ata+eye(nA));
inv_bbt = inv(bbt+eye(dB));
%% Initializing optimization variables
% intialize
J = zeros(nA,n);
Z = zeros(nA,n);
S = zeros(d,dB);
L = zeros(d,dB);
E = sparse(d,n);

Y1 = zeros(d,n);
Y2 = zeros(nA,n);
Y3 = zeros(d,dB);
%% Start main loop
display = true;
iter = 0;
if display
    disp(['initial,r(Z)=' num2str(rank(J)) ',r(L)=' num2str(rank(L)) ',|E|_1=' num2str(sum(sum(abs(E))))]);
end
while iter<maxIter
    iter = iter + 1;

    %update J
    temp = Z + Y2/mu;
	[U, sigma, V] = svd(temp, 'econ');
    sigma = diag(sigma);
    
    [tempDiagS, svp] = TS1(sigma, 1/mu, a);              
    J = U(:,1:svp)*diag(tempDiagS(1:svp))*V(:,1:svp)';
	rZ = svp; %rank(J);

    %update S
    temp = L + Y3/mu;
	[U, sigma, V] = svd(temp, 'econ');
    sigma = diag(sigma);

	[tempDiagS, svp] = TS1(sigma, 1/mu, a);    
    S = U(:,1:svp)*diag(tempDiagS(1:svp))*V(:,1:svp)';
    rL = svp; %rank(S);

    %udpate Z
    Z = inv_ata*(A'*X-A'*L*B-A'*E+J+(A'*Y1-Y2)/mu);
    
    %update L
    L = (X*B'-A*Z*B'-E*B'+S+(Y1*B'-Y3)/mu)*inv_bbt; 
    
    %update E
    temp = X-A*Z-L*B+Y1/mu;
    if type == 1
        E = max(0,temp - beta/mu)+min(0,temp + beta/mu);   %L_1
    elseif type == 2
        E = solve_l1l2(temp,beta/mu);              %L_2,1
    else 
        E = (Y1+mu*(X-A*Z-L*B))./(mu+2*beta);  %F_norm
    end
    
    %update the multiplies
    leq1 = X-A*Z-L*B-E;
    leq2 = Z-J;
    leq3 = L-S;
    stopC = max(max(max(abs(leq1))),max(max(abs(leq2))));
    stopC = max(max(max(abs(leq3))),stopC);
    if display && (iter==1 || mod(iter,50)==0 || stopC<tol)
        disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ',stopALM=' num2str(stopC,'%2.3e') ...
            ',rank(Z)=' num2str(rZ) ',rank(L)=' num2str(rL) ',|E|_1=' num2str(sum(sum(abs(E))))]);
    end
    %%
    if stopC<tol
        break;
    else
        Y1 = Y1 + mu*leq1;
        Y2 = Y2 + mu*leq2;
        Y3 = Y3 + mu*leq3;
        mu = min(max_mu,mu*rho);
    end
end


function [E] = solve_l1l2(W,lambda)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_l2(W(:,i),lambda);
end

function [x] = solve_l2(w,lambda)
% min lambda |x|_2 + |x-w|_2^2
nw = norm(w);
if nw>lambda
    x = (nw-lambda)*w/nw;
else
    x = zeros(length(w),1);
end
