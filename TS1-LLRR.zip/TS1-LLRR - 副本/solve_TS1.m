function [Z,L,E] = solve_TS1(X,beta,alpha,a,param, type)
% This routine solves the optmization problem of TS1-LLRR (noisy model)
% min T(Z) + alpha*T(L) + beta*|E|_1
% s.t., X = XZ + LX + E,
%where T(.) is the transformed Schatten-1 (TS1) penalty function.
% inputs:
%        X -- D*N data matrix, D is the data dimension, and N is the number
%             of data vectors.
%        alpha -- usually alpha = 1
%        beta  -- this parameter depends on the noise level of data
%% 
Q1 = orth(X');
Q2 = orth(X);
A = X*Q1;
B = Q2'*X;
[Z,L,E] = solve_TS1a(X,A,B,beta,alpha,a,param, type);
Z = Q1*Z;
L = L*Q2';