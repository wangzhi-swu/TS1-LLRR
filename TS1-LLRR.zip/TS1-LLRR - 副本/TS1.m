function [X,svp] = TS1(Y, lambda, a)
    X = zeros(size(Y));
    for i = 1:length(Y)
        y = Y(i);
        f = acos(1-27*lambda*a*(a+1)/(2*(a+abs(y))^3));
        g = sign(y)*(2/3*(a+abs(y))*cos(f/3)-2*a/3+abs(y)/3);
        if lambda <= a^2/(2*(a+1))
            t = lambda*(a+1)/a;
        else
            t = sqrt(2*lambda*(a+1)) - a/2;
        end
        if abs(y) <= t
            X(i) = 0;
        else
            X(i) = g;
        end
    end
    ind = find(X>0);
    svp = length(ind);
end