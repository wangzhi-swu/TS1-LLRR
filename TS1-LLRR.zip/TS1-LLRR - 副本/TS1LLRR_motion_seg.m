close all;
clear all;

datadir = './Hopkins155';
seqs = dir(datadir);
seq3 = seqs(3:end);
%% load the data
data = struct('X',{},'name',{},'ids',{});
for i=1:length(seq3)
    fname = seq3(i).name;
    fdir = [datadir '/' fname];
    if isdir(fdir)
        datai = load([fdir '/' fname '_truth.mat']);
        id = length(data)+1;
        data(id).ids = datai.s;
        data(id).name = lower(fname);
        X = reshape(permute(datai.x(1:2,:,:),[1 3 2]),2*datai.frames,datai.points);
        data(id).X = [X;ones(1,size(X,2))];
    end
end
clear seq3;
%%
%ADMM parameters
param.rho=1.08; param.mu=100;    param.tol=1e-6; param.maxIter=1e10;

type = 1; %different modeling of E.

for lambda = 3.3
    for a = 15
        for alpha = 2.25
            errs = zeros(length(data), 1);
            for i = 1 : length(data)
                X = data(i).X;
                gnd = data(i).ids;
                K = max(gnd);
                if abs(K - 2) > 0.1 && abs(K - 3) > 0.1
                    id = i; % the discarded sequqnce
                end

                Z = solve_TS1(X, lambda, 1, a, param, type);            %%%%%%%%%L1 ����
                Z = rpcapsd(Z,0.3);
                
                [U,S,V] = svd(Z);
                S = diag(S);
                r = min(4*K+1,sum(S>1e-3*S(1)));
                S = S(1:r);
                U = U(:,1:r)*diag(sqrt(S));
                U = normr(U);
                Z = U*U';Z=abs(Z);L = Z.^(2*alpha);
                
                %spectral_clustering;
                W = L;
                W = (W+W')/2;
                D = diag(1./sqrt(sum(W, 2)));
                W = D * W * D;
                [U, s, V] = svd(W);
                V = U(:, 1 : K);
                V = D*V;

                actual_ids = kmeans(V, K, 'emptyaction', 'singleton', 'replicates', 20, 'display', 'off');
                
                grps = bestMap(gnd,actual_ids);
                err = sum(gnd(:) ~= grps(:)) / length(gnd);
                
                disp(['seq ' num2str(i) ', err=' num2str(err)]);
                errs(i) = err;
            end
            toc;
            disp('results of all motions:');
            disp(['max = ' num2str(max(errs)) ',min=' num2str(min(errs)) ...
                ',median=' num2str(median(errs)) ',mean=' num2str(mean(errs)) ...
                ',std=' num2str(std(errs))] );
        end
    end
end

